import Head from "next/head";

export default function Home() {
  return (
    <div style={{ fontFamily: "sans-serif", padding: "2rem" }}>
      <Head>
        <title>Limas Car Orçamento</title>
      </Head>
      <h1 style={{ fontSize: "2rem", marginBottom: "1rem" }}>
        Bem-vindo à Limas Car!
      </h1>
      <p style={{ fontSize: "1.1rem" }}>
        Este é o início do seu sistema de orçamentos online.
      </p>
    </div>
  );
}
