export default function Home() {
  return (
    <div>
      <h1>Bem-vindo à Limas Car</h1>
      <p>Monte seu orçamento online aqui!</p>
    </div>
  );
}